# Network-Traffic-Classification
 The use of machine learning to classify network traffic.
 
 The dataset used in project was downloaded from Kaggle platform (https://www.kaggle.com/jsrojas/ip-network-traffic-flows-labeled-with-87-apps).
 
 File DataPreprocessing.ipynb implements the preparation of data for use in machine learning algorithms.
 
 In ANN, KNN and RandomForest there are application of algorithms to classify network traffic. Those algorithms were used on preprocessed CSV file created in the previous step.
 
 
